package recursion;

import java.util.ArrayList;

public class Recursion2 {

    // Minimum değeri bulan recursive fonksiyon
    public static int findMinimum(int[] arr, int index, ArrayList<String> beforeStack, ArrayList<String> afterStack) {
        // İşlem öncesi parametre durumlarını yığıta ekle
        beforeStack.add("Index: " + index);

        // Dizinin sonuna gelindiğinde minimum değer olarak dizinin son elemanını döndür
        if (index == arr.length - 1) {
            // İşlem sonrası parametre durumlarını yığıta ekle
            afterStack.add("Index: " + index);
            return arr[index];
        }

        // Recursive çağrı ile minimum değeri bul
        int minimumInRest = findMinimum(arr, index + 1, beforeStack, afterStack);

        // Şimdiki eleman ile sonraki kıyaslama yap
        int current = arr[index];
        if (current < minimumInRest) {
            minimumInRest = current;
        }

        // İşlem sonrası parametre durumlarını yığıta ekle
        afterStack.add("Index: " + index);
        return minimumInRest;
    }

    // Ana işlev
    public static void main(String[] args) {
        int[] arr = {4, 2, 7, 1, 9, 3};
        int n = arr.length;

        ArrayList<String> beforeStack = new ArrayList<>();
        ArrayList<String> afterStack = new ArrayList<>();

        int minimum = findMinimum(arr, 0, beforeStack, afterStack);

        System.out.println("Dizinin minimum değeri: " + minimum);

        // İşlem öncesi durumları göster
        System.out.println("İşlem öncesi durumlar:");
        for (String state : beforeStack) {
            System.out.println(state);
        }

        // İşlem sonrası durumları göster
        System.out.println("İşlem sonrası durumlar:");
        for (String state : afterStack) {
            System.out.println(state);
        }
    }
}
