package recursion;

import java.util.ArrayList;

public class Recursion {
    // İkili arama fonksiyonu
    public static int binarySearch(int[] arr, int low, int high, int x, ArrayList<String> beforeStack, ArrayList<String> afterStack) {
        // İşlem öncesi parametre durumlarını yığıta ekle
        beforeStack.add("(" + low + ", " + high + ")");

        if (high >= low) {
            int mid = low + (high - low) / 2;

            // Hedef öğe tam olarak ortada mı?
            if (arr[mid] == x) {
                // İşlem sonrası parametre durumlarını yığıta ekle
                afterStack.add("(" + low + ", " + high + ")");
                return mid;
            }
            // Hedef öğe ortanın solundaysa
            else if (arr[mid] > x) {
                return binarySearch(arr, low, mid - 1, x, beforeStack, afterStack);
            }
            // Hedef öğe ortanın sağındaysa
            else {
                return binarySearch(arr, mid + 1, high, x, beforeStack, afterStack);
            }
        }

        // İşlem sonrası parametre durumlarını yığıta ekle
        afterStack.add("(" + low + ", " + high + ")");
        // Hedef öğe bulunamadı
        return -1;
    }

    // Ana işlev
    public static void main(String[] args) {
        int[] arr = {2, 3, 4, 10, 40};
        int x = 10;
        int n = arr.length;

        ArrayList<String> beforeStack = new ArrayList<>();
        ArrayList<String> afterStack = new ArrayList<>();

        int result = binarySearch(arr, 0, n - 1, x, beforeStack, afterStack);

        if (result != -1) {
            System.out.println("Eleman " + result + ". indekste bulundu.");
        } else {
            System.out.println("Eleman bulunamadı.");
        }

        // İşlem öncesi durumları göster
        System.out.println("İşlem öncesi durumlar:");
        for (String state : beforeStack) {
            System.out.println(state);
        }

        // İşlem sonrası durumları göster
        System.out.println("İşlem sonrası durumlar:");
        for (String state : afterStack) {
            System.out.println(state);
        }
    }
}

